/// <reference types="next" />
/// <reference types="next/navigation-types/compat/navigation" />
